# BREAK IT Reproducible Evidence Bundle

## Contents
- `manifest.json` — Component hash, scenario/assertion pack hash, candidate provenance, Chromium version, and measured run summaries.
- `component/` — `original.html`, `instrumented.html`, `original.css`, `candidate.css` (if generated), `spark-original-proposal.css` (if manually edited after Spark generation), and `patch.diff`.
- `pack/` — Exact `scenarios.json`, `assertions.json`, and `slots.json`.
- `evidence/` — Full measured Chromium JSON logs, candidate provenance, secret-free model receipts, and before/after PNG screenshots.
- `repro/evaluator-core.mjs`, `repro/fonts.css`, & `repro/reproduce.mjs` — Exact compiled evaluation engine, embedded WOFF2 fonts, and Playwright runner matching the BREAK IT server.

## Reproduce from Terminal
From any directory where `playwright` is installed (such as the BREAK IT repo):

```bash
# Verify expected failures on original CSS (exits with code 1 when any failure, error, or inconclusive rule occurs)
node repro/reproduce.mjs --target original

# Verify candidate CSS against the exact same scenario + assertion pack (exits with code 0 only if 100% pass)
node repro/reproduce.mjs --target candidate
```
