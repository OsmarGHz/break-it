#!/usr/bin/env node
/**
 * BREAK IT — Full-Parity Chromium Reproduction Runner.
 * Uses the exact compiled evaluator-core.mjs + bundled WOFF2 fonts + isolated
 * Chromium context settings as the application server.
 *
 * Unknown, inconclusive, or errored assertions are NEVER treated as passes;
 * any non-passing scenario exits with code 1.
 *
 * Usage:
 *   node repro/reproduce.mjs --target original
 *   node repro/reproduce.mjs --target candidate
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import {
  aggregateStatus,
  buildBrowserInspectionExpression,
  buildIsolatedRenderDocumentWithFonts,
  collectInspectionTargetIds,
  evaluateSingleAssertion,
} from './evaluator-core.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const bundleRoot = path.resolve(__dirname, '..');

const args = process.argv.slice(2);
const targetIdx = args.indexOf('--target');
const target = targetIdx >= 0 && args[targetIdx + 1] ? args[targetIdx + 1] : 'candidate';

const instrumentedHtml = fs.readFileSync(path.join(bundleRoot, 'component', 'instrumented.html'), 'utf8');
const cssFile = target === 'original' ? 'original.css' : 'candidate.css';
const cssPath = path.join(bundleRoot, 'component', cssFile);

if (!fs.existsSync(cssPath)) {
  console.error(`Requested stylesheet component/${cssFile} does not exist in this bundle. Try --target original.`);
  process.exit(2);
}

const css = fs.readFileSync(cssPath, 'utf8');
const fontFaceCss = fs.existsSync(path.join(__dirname, 'fonts.css'))
  ? fs.readFileSync(path.join(__dirname, 'fonts.css'), 'utf8')
  : '';
const scenarios = JSON.parse(fs.readFileSync(path.join(bundleRoot, 'pack', 'scenarios.json'), 'utf8'));
const assertions = JSON.parse(fs.readFileSync(path.join(bundleRoot, 'pack', 'assertions.json'), 'utf8'));
const slots = JSON.parse(fs.readFileSync(path.join(bundleRoot, 'pack', 'slots.json'), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(bundleRoot, 'manifest.json'), 'utf8'));
const rootTargetId = manifest.rootTargetId || 'card-root';

const enabledAssertions = assertions.filter((a) => a.enabled);
if (enabledAssertions.length === 0) {
  console.error('No enabled assertions in pack/assertions.json — refusing to report pass.');
  process.exit(1);
}

const slotMap = new Map(slots.map((s) => [s.id, s]));
const targetIds = collectInspectionTargetIds(rootTargetId, slots, enabledAssertions);
const browserInspectionExpr = buildBrowserInspectionExpression(targetIds, rootTargetId);

const browser = await chromium.launch({
  headless: true,
  args: [
    '--disable-background-networking',
    '--disable-default-apps',
    '--disable-extensions',
    '--disable-sync',
    '--no-first-run',
    '--hide-scrollbars',
  ],
});

let passedCount = 0;
let nonPassingCount = 0;

console.log(`\n=== BREAK IT Full-Parity Repro Runner (target: ${target}, browser: Chromium ${browser.version()}) ===`);

try {
  for (const sc of scenarios) {
    const vpWidth = Math.min(1600, Math.max(240, Math.round(sc.viewport.width)));
    const vpHeight = Math.min(1600, Math.max(320, Math.round(sc.viewport.height)));

    const expectedSlotTexts = {};
    for (const s of slots) {
      expectedSlotTexts[s.id] = s.originalText;
    }

    const context = await browser.newContext({
      viewport: { width: vpWidth, height: vpHeight },
      deviceScaleFactor: 2,
      javaScriptEnabled: false,
      acceptDownloads: false,
      serviceWorkers: 'block',
      locale: 'es-MX',
      timezoneId: 'America/Mexico_City',
      reducedMotion: 'reduce',
      colorScheme: 'light',
    });

    await context.route('**/*', (route) => {
      const u = route.request().url();
      if (u === 'about:blank' || u.startsWith('data:image/') || u.startsWith('data:font/')) {
        return route.continue();
      }
      return route.abort('blockedbyclient');
    });

    try {
      const page = await context.newPage();
      const baseDoc = buildIsolatedRenderDocumentWithFonts(instrumentedHtml, css, fontFaceCss);
      await page.setContent(baseDoc, { waitUntil: 'load', timeout: 12000 });

      // Apply validated textContent-only mutations identically to server/sanitizer.ts
      const cleanMutations = [];
      for (const mut of sc.mutations || []) {
        if (!slotMap.has(mut.slotId)) {
          throw new Error(`Invalid mutation target slotId "${mut.slotId}"`);
        }
        const cleanVal = String(mut.value ?? '')
          .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
          .slice(0, 280);
        if (!cleanVal.trim()) {
          throw new Error(`Mutation for slot "${mut.slotId}" cannot empty out required text.`);
        }
        expectedSlotTexts[mut.slotId] = cleanVal.replace(/\s+/g, ' ').trim();
        cleanMutations.push({ slotId: mut.slotId, value: cleanVal });
      }

      if (cleanMutations.length > 0) {
        const mutPayload = JSON.stringify(cleanMutations);
        await page.evaluate(`(() => {
          const list = ${mutPayload};
          for (const m of list) {
            const el = document.querySelector('[data-breakit-id="' + m.slotId + '"]');
            if (!el) throw new Error('Target element [data-breakit-id="' + m.slotId + '"] not found');
            el.textContent = m.value;
          }
          return document.body ? document.body.offsetHeight : 0;
        })()`);
      }

      await page.evaluate('document.fonts && document.fonts.ready ? document.fonts.ready.then(() => true) : true');
      const inspection = await page.evaluate(browserInspectionExpr);

      const results = enabledAssertions.map((rule) => {
        try {
          return evaluateSingleAssertion(rule, inspection, rootTargetId, expectedSlotTexts, slotMap);
        } catch (err) {
          return {
            assertionId: rule.id,
            assertionLabel: rule.label,
            assertionType: rule.type,
            status: 'error',
            summary: `Assertion evaluation error: ${err instanceof Error ? err.message : String(err)}`,
          };
        }
      });

      const overallStatus = aggregateStatus(results.map((r) => r.status));
      if (overallStatus === 'pass') {
        passedCount += 1;
        console.log(`  PASS  ${sc.id} (${vpWidth}x${vpHeight})`);
      } else {
        nonPassingCount += 1;
        const nonPassDetails = results
          .filter((r) => r.status !== 'pass')
          .map((r) => `[${r.status.toUpperCase()} ${r.assertionId}] ${r.summary}`)
          .join(' | ');
        console.log(`  ${overallStatus.toUpperCase()}  ${sc.id} (${vpWidth}x${vpHeight}): ${nonPassDetails}`);
      }
    } catch (err) {
      nonPassingCount += 1;
      console.log(`  ERROR ${sc.id} (${vpWidth}x${vpHeight}): ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      await context.close();
    }
  }
} finally {
  await browser.close();
}

console.log(`\nSummary (${target}): ${passedCount}/${scenarios.length} scenarios passed, ${nonPassingCount} non-passing.\n`);
process.exit(nonPassingCount > 0 ? 1 : 0);
